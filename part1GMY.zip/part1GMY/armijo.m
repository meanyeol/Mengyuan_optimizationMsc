function alpha_k = armijo(a,sigma,x_k,d_k,gamma,g)

j=0;
while(1)
    
    
    alpha = a*sigma^j;   
    x = x_k+alpha*d_k;
    error=rosenbrock(x)-rosenbrock(x_k);
    if error <=gamma*alpha*g'*d_k
        alpha_k = alpha;  
        break;
    end
    j=j+1;
end

end