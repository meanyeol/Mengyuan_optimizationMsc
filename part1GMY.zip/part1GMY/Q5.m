clear;
clc;
%% A5: Polak-Ribiere algorithm with Armijo Line Search
%step 1 initialization && definition:
% x0  :  starting point  vector [X,Y]     ///     x_k   :    each iterated point value
%k   :  iteration times                        ///      tol   :    tolerance for error
% alpha_k  : step length for each iteration
%d_k   :   direction for each iteration
%Armijo parameters: a , sigmma , gamma
%j_k : cost function for each point
%J_k : cost functions set
% Set()  :  [X,Y] points set
%d_kbef  : set of previous d, to get d_(k-1)
%%%%%%%%%%%%%%%%%
x0=[-3/4;1];
x_k=x0;
k=0;
sigma=0.5;
gamma=0.37;
a=1;
tol=0.000001;
while(1)
    Set(:,k+1)=x_k;
    j_k=log((x_k(1)-1)^2+(x_k(2)-1)^2);
    J_k(:,k+1)=j_k;
    g=gradient(x_k);
    % break judgment
    if norm(g)<tol
        break;
    end
    % compute direction d_k
        if k==0
            d_k=-g;
        else
            d_k=-g+((g'*(g-gradient(Set(:,k)))*d_kbef(:,k))/(norm(gradient(Set(:,k))))^2);
        end
    
    % call Armijo to calculate step length (Step 3 in notebook)
    alpha_k=armijo(a,sigma,x_k,d_k,gamma,g);
    %step4 compute x_k and repeat
    x_k=x_k+alpha_k*d_k;
    k=k+1;
    % store direction into the set
    d_kbef(:,k)=d_k;
end

%% plot for A8a and A8b
% A8a plot sequences of point
X=-2.5:0.05:2.5;
Y=-1.5:0.05:5;
[X,Y]=meshgrid(X,Y);
v=100*(Y-X.^2).^2+(1-X).^2;
figure(51)
Line=[0,0.1,0.25,0.5,1.5,10,30,70,110,160,200,400,800];
contour(X,Y,v,Line,'ShowText','on')
% level line
hold on; 
plot(Set(1,:),Set(2,:),'r-.','linewidth', 2); 
%sequences of point
xlabel('X');
ylabel('Y');
hold on
plot(1,1,'.k','markersize',20)
% stationary point
title('Minimization using Polak-Ribiere Algorithm with Armijo Line Search');
legend('Level Sets','Sequences of points','Stationary Point')

%A8b plot cost function 
figure(52)
num=(0:k);
plot(num(1,:),J_k(1,:));
xlabel('Sequences of k');
ylabel('J_k');
title('Cost Function of The Polak-Ribiere Algorithm with Armijo Line Search');
legend('Cost Function')




