clear;
clc
 %% A7 Downhill Simplex Method Improvement
k=0; 
%choose three random starting points to shape a equally spaced triangle.
x0=[-0.75;1];                                                                                                  
% x1 = [-0.5;1];
% x2 = [-0.625;0.7835];
 % form an equally speced triangle, chang=length of triangle
chang = 0.6;
x1 = [x0(1)+chang;x0(2)];
x2 = [x0(1)+chang/2; x0(2)-sqrt(3)/2*chang];
% x1=[x0(1)+chang/2;x0(2)+sqrt(3)/2*chang];
% x2=[x0(1)-chang/2;x0(2)+sqrt(3)/2*chang];
% x1=[x0(1)-chang;x0(2)];
% x2=[x0(1)-chang/2;x0(2)-sqrt(3)/2*chang];
P = [x0 x1 x2];
I=1;
alpha = 1 ; % reflection
gamma =2;  % expansion
belta = 0.5;  % contraction
sigma=0.5; % shrink
 tol = 1e-25;
 Set(:,1) = x0; Set(:,2) = x1;  Set(:,3) = x2;
 while (1)
     j_k = log((P(1,I)-1)^2 + (P(2,I)-1)^2);
     J_k(:,k+1) = j_k;
     %average function value
     favg = (rosenbrock(P(:,1))+rosenbrock(P(:,2))+rosenbrock(P(:,3)))/3;
     criterion = ((rosenbrock(P(:,1))-favg)^2+(rosenbrock(P(:,2))-favg)^2+(rosenbrock(P(:,3))-favg)^2)/3;
     if criterion < tol
        break;
     end
     % X avg of best and good
     F = [rosenbrock(P(:,1));rosenbrock(P(:,2));rosenbrock(P(:,3))];
     [M,I]=max(F);
     %the maximum value
     Xn=P(:,I);
     Xavg = (P(:,1)+P(:,2)+P(:,3)-Xn)/2;  
     %reflection 
     Xr = Xavg+alpha*(Xavg-P(:,I));
     Pc=P;
     %replace worst one to Xr
     Pc(:,I) = Xr;  
     %new three point
     F = [rosenbrock(Pc(:,1));rosenbrock(Pc(:,2));rosenbrock(Pc(:,3))];
     %
     %expansion
     if min(F)==rosenbrock(Xr)
         %y*
         Xe=Xr+gamma*(Xr-Xavg);
         %y**
         if rosenbrock(Xe)<rosenbrock(Xr)
             P(:,I)=Xe;
         else
             P(:,I)=Xr;
         end
     %contraction

            % y*=Xr
         elseif (rosenbrock(Xr)<=rosenbrock(P(:,1)) || rosenbrock(Xr)<=rosenbrock(P(:,2)) || rosenbrock(Xr)<=rosenbrock(P(:,3))) && rosenbrock(Xr)< max(F)
             P(:,I)=Xr;
         %condition 3 from nelder-mead
         else
             if rosenbrock(Xr) <= max(F)
                 P(:,I)=Xr;
             end
             %get second need-to-change value y**
             Xc=Xavg+belta*(Xn-Xavg);
             % Shrink
             if rosenbrock(Xc)>max(F)
                             [Xiao,lo]=min(F);
                             X1=P(:,lo);
                             for i = 1:3
                                 P(:,i)=X1+sigma*(P(:,i)-X1);
                             end
             else
                 P(:,I)=Xc;
             end
         end
   
     k=k+1;
     Set(:,k+3) = P(:,I);
      
    
 end
 %% plot for A8a and A8b
%A8a plot sequences of point
X=-2.5:0.05:2.5;
Y=-1.5:0.05:5;
[X,Y]=meshgrid(X,Y);
v=100*(Y-X.^2).^2+(1-X).^2;
figure(91)
Line=[0,0.1,0.25,0.5,1.5,10,30,70,110,160,200,400,800];
contour(X,Y,v,Line,'ShowText','on')
hold on; 
plot(Set(1,:),Set(2,:),'r-.','linewidth', 2); 
xlabel('X');
ylabel('Y');
hold on
plot(1,1,'.k','markersize',20)
title('Minimization using Downhill Simplex Improved method-2');
legend('Level Sets','Sequences of points','Stationary Point')

% plot cost function 
figure(92)
num=(0:k);
plot(num(1,:),J_k(1,:));
xlabel('Sequences of k');
ylabel('J_k');
title('Cost Function of The Downhill Simplex Improved method-2');
legend('Cost Function')








