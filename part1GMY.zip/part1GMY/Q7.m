clear;
clc
close all
 %% A7 Simplex Method only with Reflection
 %step 1 initialization && definition:
% x0  :  starting point  vector [X,Y]     /// 
%k   :  iteration times                        ///      tol   :    tolerance for error
% P : array of adjacent three points
%j_k : cost function for each point
%J_k : cost functions set
% Set()  :  [X,Y] points set
% favg  :  average rosenbrock value of three points
% Xcenter: the center of three point
%%%%%%%%%%%%%%%%%
 x0=[-0.75;1];
 k=0;
% form an equally speced triangle, chang=length of triangle
chang=0.3;% change that into different values to get different starting points
x1=[x0(1)+chang/2;x0(2)+sqrt(3)/2*chang];
x2=[x0(1)-chang/2;x0(2)+sqrt(3)/2*chang];
% x1=[x0(1)-chang;x0(2)];
% x2=[x0(1)-chang/2;x0(2)-sqrt(3)/2*chang];
P = [x0 x1 x2];
I=1;
a=1.98;% change a=1.98 or 1, or other value: non-convergence
 tol = 1e-25; % tolerance
 Set(:,1) = x0; Set(:,2) = x1;  Set(:,3) = x2;
 while (1)
     j_k = log((P(1,I)-1)^2 + (P(2,I)-1)^2);
     J_k(:,k+1) = j_k;
     favg = (rosenbrock(P(:,1))+rosenbrock(P(:,2))+rosenbrock(P(:,3)))/3;
     %stopping criterion
     chazhi=((rosenbrock(P(:,1))-favg)^2+(rosenbrock(P(:,2))-favg)^2+(rosenbrock(P(:,3))-favg)^2)/3 ;
     if chazhi< tol
        break;
      end
     Xcenter = (P(:,1)+P(:,2)+P(:,3))/3;  
     F = [rosenbrock(P(:,1));rosenbrock(P(:,2));rosenbrock(P(:,3))];
     %get worst index and function value
     [M,I]=max(F);
     % Reflection
     Xn = Xcenter+a*(Xcenter-P(:,I));
     P(:,I) = Xn;   
     k=k+1;
     Set(:,k+3) = P(:,I);        
 end

%% plot for A8a and A8b
%A8a plot sequences of point
X=-2.5:0.05:2.5;
Y=-1.5:0.05:5;
[X,Y]=meshgrid(X,Y);
v=100*(Y-X.^2).^2+(1-X).^2;
figure(71)
Line=[0,0.1,0.25,0.5,1.5,10,30,70,110,160,200,400,800];
contour(X,Y,v,Line,'ShowText','on')
hold on; 
plot(Set(1,:),Set(2,:),'r-.','linewidth', 2); 
xlabel('X');
ylabel('Y');
hold on
plot(1,1,'.k','markersize',20)
title('Minimization using Simplex Method, using reflection');
legend('Level Sets','Sequences of points','Stationary Point')

% plot cost function 
figure(72)
num=(0:k);
plot(num(1,:),J_k(1,:));
xlabel('Sequences of k');
ylabel('J_k');
title('Cost Function of The Simplex Method, using reflection');
legend('Cost Function')




