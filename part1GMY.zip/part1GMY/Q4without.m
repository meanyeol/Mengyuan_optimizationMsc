clear;
clc;
%% A4 Second part:Newton without Armijo for A4
%step 1 initialization && definition:
% x0  :  starting point  vector [X,Y]     ///     x_k   :    each iterated point value
%k   :  iteration times                        ///      tol   :    tolerance for error
%j_k : cost function for each point
%J_k : cost functions set
% Set()  :  [X,Y] points set
%%%%%%%%%%%%%%%%%
x0=[-3/4;1];
x_k=x0;
k=0;
tol=0.000001;
while(1)
    Set(:,k+1)=x_k;
    j_k=log((x_k(1)-1)^2+(x_k(2)-1)^2);
    J_k(:,k+1)=j_k;
    %(Step 2 in notebook)
    g=gradient(x_k);
    H=hessian(x_k);
    s=-(H)^(-1)*g;
    if norm(g)<tol  % or write as "norm(g)==0" which doesn't allow tolerence
        break;
    end
   % compute x_k and repeat
    x_k=x_k+s;
    k=k+1;
end
%% plot for A8a and A8b
% A8a plot sequences of point
X=-2.8:0.05:2.8;
Y=-2.8:0.05:5;
[X,Y]=meshgrid(X,Y);
v=100*(Y-X.^2).^2+(1-X).^2;
figure(411)
Line=[0,0.1,0.25,0.5,1.5,10,30,70,110,160,200,400,800];
contour(X,Y,v,Line,'ShowText','on')
% level line 
hold on; 
plot(Set(1,:),Set(2,:),'r-.+','linewidth', 2); 
% sequences of point [x,y]
xlabel('X');
ylabel('Y');
hold on
plot(1,1,'.k','markersize',20)
% stationary point
title('Minimization using Newton Method without Armijo Line Search');
legend('Level Sets','Sequences of points','Stationary Point')

% A8b plot cost function 
figure(422)
num=(0:k);
plot(num(1,:),J_k(1,:));
xlabel('Sequences of k');
ylabel('J_k');
title('Cost Function of The Newton Method without Armijo Line Search');
legend('Cost Function')




